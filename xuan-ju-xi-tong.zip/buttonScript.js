
const goRegistrationBtn = document.getElementById("goRegistrationBtn");
if (goRegistrationBtn) {
  goRegistrationBtn.addEventListener("click", function () {
    window.location.href = "registrationPage.html";
  });
}



// 首页的按钮：跳转到 page2.html
const goBtn = document.getElementById("goBtn");
if (goBtn) {
  goBtn.addEventListener("click", function () {
    window.location.href = "page2.html";
  });
}

// 第二页的按钮：跳回 index.html
const backBtn = document.getElementById("backBtn");
if (backBtn) {
  backBtn.addEventListener("click", function () {
    window.location.href = "index.html";
  });
}

const loginBtn = document.getElementById("loginBtn")


const sendCodeBtn = document.getElementById("sendCodeBtn");

if (sendCodeBtn) {
  sendCodeBtn.addEventListener("click", function () {
    alert("验证码：114514");
  });
}