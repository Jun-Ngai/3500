const express = require("express");
const { Pool } = require("pg");
const cors = require("cors");
const path = require("path");

const app = express();
const PORT = process.env.PORT || 3000;

// ===== 中介軟體 =====
app.use(cors());
app.use(express.json());
app.use(express.static(__dirname));

// ===== 連接 PostgreSQL（Render 免費資料庫）=====
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: { rejectUnauthorized: false } // 雲端資料庫必須開啟 SSL
});

// ===== 建立 users 資料表（若不存在）=====
async function initDatabase() {
  try {
    await pool.query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name TEXT NOT NULL,
        id_number TEXT NOT NULL UNIQUE,
        phone TEXT NOT NULL,
        created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
      )
    `);
    console.log("資料表已就緒");
  } catch (err) {
    console.error("建立資料表失敗：", err.message);
  }
}
initDatabase();

// ===== API：註冊 =====
app.post("/api/register", async (req, res) => {
  const { name, idNumber, phone } = req.body;

  const nameOk = /^[A-Za-z]+$/.test(name || "");
  const idOk = /^[A-Za-z0-9]{8}$/.test(idNumber || "");
  const phoneOk = /^[0-9]{8}$/.test(phone || "");

  if (!nameOk || !idOk || !phoneOk) {
    return res.status(400).json({ success: false, message: "資料格式錯誤" });
  }

  try {
    const existing = await pool.query(
      "SELECT id FROM users WHERE id_number = $1",
      [idNumber]
    );
    if (existing.rows.length > 0) {
      return res.status(409).json({ success: false, message: "此身份證號已註冊" });
    }

    const result = await pool.query(
      "INSERT INTO users (name, id_number, phone) VALUES ($1, $2, $3) RETURNING id",
      [name, idNumber, phone]
    );

    res.json({ success: true, message: "註冊成功", userId: result.rows[0].id });
  } catch (err) {
    console.error("註冊錯誤：", err.message);
    res.status(500).json({ success: false, message: "資料庫錯誤" });
  }
});

// ===== API：登入 =====
app.post("/api/login", async (req, res) => {
  const { name, idNumber } = req.body;

  try {
    const result = await pool.query(
      "SELECT id, name, id_number, phone FROM users WHERE name = $1 AND id_number = $2",
      [name, idNumber]
    );

    if (result.rows.length === 0) {
      return res.status(401).json({ success: false, message: "名字或身份證號錯誤" });
    }

    res.json({ success: true, message: "登入成功", user: result.rows[0] });
  } catch (err) {
    console.error("登入錯誤：", err.message);
    res.status(500).json({ success: false, message: "資料庫錯誤" });
  }
});

// ===== API：查詢所有用戶（測試用）=====
app.get("/api/users", async (req, res) => {
  try {
    const result = await pool.query(
      "SELECT id, name, id_number, phone, created_at FROM users ORDER BY id"
    );
    res.json({ success: true, users: result.rows });
  } catch (err) {
    console.error("查詢錯誤：", err.message);
    res.status(500).json({ success: false, message: "資料庫錯誤" });
  }
});

// ===== 啟動伺服器 =====
app.listen(PORT, '0.0.0.0', () => {
  console.log(`伺服器運行中：http://localhost:${PORT}`);
});