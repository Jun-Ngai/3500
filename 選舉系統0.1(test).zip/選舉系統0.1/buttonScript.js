const goRegistrationBtn = document.getElementById("goRegistrationBtn");
if (goRegistrationBtn) {
  goRegistrationBtn.addEventListener("click", function () {
    window.location.href = "registrationPage.html";
  });
}

// 首页的按钮：跳转到 page2.html
const goBtn = document.getElementById("goBtn");
if (goBtn) {
  goBtn.addEventListener("click", function () {
    window.location.href = "page2.html";
  });
}

// 第二页 / 登录页的按钮：跳回 index.html
const backBtn = document.getElementById("backBtn");
if (backBtn) {
  backBtn.addEventListener("click", function () {
    window.location.href = "index.html";
  });
}

// 注册页的「登录」按钮：跳到 loginPage.html
const goLoginBtn = document.getElementById("goLoginBtn");
if (goLoginBtn) {
  goLoginBtn.addEventListener("click", function () {
    window.location.href = "loginPage.html";
  });
}

const loginBtn = document.getElementById("loginBtn");

// 发送验证码
const sendCodeBtn = document.getElementById("sendCodeBtn");
if (sendCodeBtn) {
  sendCodeBtn.addEventListener("click", function () {
    const code = String(Math.floor(Math.random() * 1000000)).padStart(6, "0");
    alert("验证码：" + code);
  });
}

// ===== 驗證規則 =====
const NAME_RULE = "名字只能包含大小寫英文字母，不能有數字或符號。";
const ID_RULE = "身份證號碼必須是 8 個字符，（例如：A1234567）。";
const PHONE_RULE = "手機號必須是 8 個數字（0-9），不能包含字母或符號。";

// 驗證名字：只能英文
function isValidName(name) {
  return /^[A-Za-z]+$/.test(name);
}

// 驗證身份證號碼：8 個字符，只能數字 + 字母
function isValidId(id) {
  return /^[A-Za-z0-9]{8}$/.test(id);
}

// 驗證手機號：8 個數字
function isValidPhone(phone) {
  return /^[0-9]{8}$/.test(phone);
}

// 顯示錯誤訊息
function showError(inputEl, message) {
  const errorEl = document.getElementById(inputEl.id + "Error");
  if (errorEl) {
    errorEl.textContent = message;
    errorEl.classList.add("show");
  }
  inputEl.classList.add("input-error");
}

function clearError(inputEl) {
  const errorEl = document.getElementById(inputEl.id + "Error");
  if (errorEl) {
    errorEl.textContent = "";
    errorEl.classList.remove("show");
  }
  inputEl.classList.remove("input-error");
}

// 驗證單一欄位，回傳 true / false
function validateField(inputEl, type) {
  const value = inputEl.value.trim();

  if (value === "") {
    showError(inputEl, "此欄位不能為空。");
    return false;
  }

  if (type === "name" && !isValidName(value)) {
    showError(inputEl, NAME_RULE);
    return false;
  }

  if (type === "id" && !isValidId(value)) {
    showError(inputEl, ID_RULE);
    return false;
  }

  if (type === "phone" && !isValidPhone(value)) {
    showError(inputEl, PHONE_RULE);
    return false;
  }

  clearError(inputEl);
  return true;
}

// ===== 註冊頁 =====
const RegistrationForm = document.getElementById("RegistrationForm");
if (RegistrationForm) {
  const usernameEl = document.getElementById("username");
  const passwordEl = document.getElementById("password");
  const phoneEl = document.getElementById("phone");
  const codeEl = document.getElementById("code");

  RegistrationForm.addEventListener("submit", function (e) {
    e.preventDefault();

    // 每次提交前先清空所有錯誤
    clearError(usernameEl);
    clearError(passwordEl);
    clearError(phoneEl);
    clearError(codeEl);

    const okName = validateField(usernameEl, "name");
    const okId = validateField(passwordEl, "id");
    const okPhone = validateField(phoneEl, "phone");

    if (!okName) {
      usernameEl.focus();
      return;
    }
    if (!okId) {
      passwordEl.focus();
      return;
    }
    if (!okPhone) {
      phoneEl.focus();
      return;
    }

    if (codeEl.value.trim() === "") {
      showError(codeEl, "請輸入驗證碼。");
      codeEl.focus();
      return;
    }

    alert("註冊成功！");
    // 這裡可以加入提交到後端的邏輯
  });
}

// ===== 登入頁 =====
const loginForm = document.getElementById("loginForm");
if (loginForm) {
  const usernameEl = document.getElementById("username");
  const passwordEl = document.getElementById("password");

  loginForm.addEventListener("submit", function (e) {
    e.preventDefault();

    clearError(usernameEl);
    clearError(passwordEl);

    if (!isValidName(usernameEl.value.trim())) {
      if (usernameEl.value.trim() === "") {
        showError(usernameEl, "此欄位不能為空。");
      } else {
        showError(usernameEl, "格式錯誤：" + NAME_RULE);
      }
      usernameEl.focus();
      return;
    }
    clearError(usernameEl);

    if (!isValidId(passwordEl.value.trim())) {
      if (passwordEl.value.trim() === "") {
        showError(passwordEl, "此欄位不能為空。");
      } else {
        showError(passwordEl, "格式錯誤：" + ID_RULE);
      }
      passwordEl.focus();
      return;
    }
    clearError(passwordEl);

    alert("登入成功！");
    // 這裡可以加入提交到後端的邏輯
  });
}